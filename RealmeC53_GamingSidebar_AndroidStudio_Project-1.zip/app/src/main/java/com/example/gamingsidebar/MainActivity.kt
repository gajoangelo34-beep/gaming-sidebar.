package com.example.gamingsidebar

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.graphics.Color

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 40, 32, 32)
            setBackgroundColor(Color.rgb(17, 17, 17))
        }
        layout.addView(TextView(this).apply {
            text = "REALME C53 • GAMING SIDEBAR"
            textSize = 22f; setTextColor(Color.WHITE); setPadding(0, 0, 0, 18)
        })
        layout.addView(TextView(this).apply {
            text = "FPS panel included: it reports display refresh rate when available, not CODM's actual rendered FPS. Android normally restricts third-party apps from reading another game's live FPS."
            textSize = 15f; setTextColor(Color.LTGRAY); setPadding(0, 0, 0, 24)
        })
        layout.addView(Button(this).apply {
            text = "Grant overlay permission"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            }
        })
        layout.addView(Button(this).apply {
            text = "Start gaming sidebar"
            setOnClickListener {
                if (Settings.canDrawOverlays(this@MainActivity)) {
                    startService(Intent(this@MainActivity, OverlayService::class.java)); finish()
                } else startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            }
        })
        layout.addView(Button(this).apply {
            text = "Stop sidebar"
            setOnClickListener { stopService(Intent(this@MainActivity, OverlayService::class.java)) }
        })
        setContentView(layout)
    }
}
