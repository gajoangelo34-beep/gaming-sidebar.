package com.example.gamingsidebar

import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.media.AudioManager
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import android.app.AlertDialog
import android.widget.EditText
import android.os.Handler
import android.os.Looper

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private var bubble: View? = null
    private var panel: View? = null
    private var seconds = 0
    private var running = false
    private val handler = Handler(Looper.getMainLooper())
    private var timerText: TextView? = null
    private val tick = object : Runnable {
        override fun run() {
            if (running) {
                seconds++
                timerText?.text = "Stopwatch: ${seconds / 60}:${(seconds % 60).toString().padStart(2, '0')}"
                handler.postDelayed(this, 1000)
            }
        }
    }

    private fun params(width: Int, height: Int): WindowManager.LayoutParams {
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
        return WindowManager.LayoutParams(width, height, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.END; x = 12; y = 240 }
    }

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        showBubble()
    }

    private fun showBubble() {
        val b = TextView(this).apply {
            text = "G"
            textSize = 20f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.rgb(190, 25, 35))
            setPadding(18, 14, 18, 14)
            setOnClickListener { if (panel == null) showPanel() else hidePanel() }
        }
        bubble = b
        val p = params(WRAP_CONTENT, WRAP_CONTENT)
        b.setOnTouchListener(object : View.OnTouchListener {
            var sx = 0f; var sy = 0f; var moved = false
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; moved = false; return true }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = (sx - e.rawX).toInt(); val dy = (e.rawY - sy).toInt()
                        if (kotlin.math.abs(dx) > 5 || kotlin.math.abs(dy) > 5) moved = true
                        p.x = (p.x + dx).coerceAtLeast(0); p.y = (p.y + dy).coerceAtLeast(0)
                        wm.updateViewLayout(v, p); sx = e.rawX; sy = e.rawY; return true
                    }
                    MotionEvent.ACTION_UP -> { if (!moved) v.performClick(); return true }
                }
                return false
            }
        })
        wm.addView(b, p)
    }

    private fun showPanel() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 16, 18, 16)
            setBackgroundColor(Color.rgb(24, 24, 24))
        }
        val heading = TextView(this).apply {
            text = "GAMING PANEL"
            textSize = 18f
            setTextColor(Color.rgb(255, 70, 70))
            setPadding(0, 0, 0, 12)
        }
        timerText = TextView(this).apply {
            text = "Stopwatch: 0:00"
            textSize = 14f
            setTextColor(Color.WHITE)
            setPadding(0, 6, 0, 8)
        }
        fun button(label: String, action: () -> Unit) {
            box.addView(Button(this).apply { text = label; setOnClickListener { action() } })
        }
        box.addView(heading)
        box.addView(timerText)
        button("Start / pause stopwatch") {
            running = !running
            if (running) handler.post(tick) else handler.removeCallbacks(tick)
        }
        button("Reset stopwatch") {
            running = false; handler.removeCallbacks(tick); seconds = 0
            timerText?.text = "Stopwatch: 0:00"
        }
        button("Volume +") { adjustVolume(AudioManager.ADJUST_RAISE) }
        button("Volume -") { adjustVolume(AudioManager.ADJUST_LOWER) }
        button("Quick note") { showNoteDialog() }
        button("Hide panel") { hidePanel() }
        panel = box
        wm.addView(box, params(260, WRAP_CONTENT).apply {
            flags = WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
        })
    }

    private fun adjustVolume(direction: Int) {
        val audio = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, direction, AudioManager.FLAG_SHOW_UI)
    }

    private fun showNoteDialog() {
        val edit = EditText(this).apply { hint = "Type a quick note" }
        AlertDialog.Builder(this)
            .setTitle("Gaming note")
            .setView(edit)
            .setPositiveButton("Close") { _, _ ->
                Toast.makeText(this, edit.text.toString().ifBlank { "No note entered" }, Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Cancel", null)
            .show()
            .window?.setType(if (Build.VERSION.SDK_INT >= 26)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE)
    }

    private fun hidePanel() {
        panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        panel = null
    }

    override fun onDestroy() {
        running = false; handler.removeCallbacks(tick)
        hidePanel()
        bubble?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        bubble = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
