package com.example.gamingsidebar

import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.media.AudioManager
import android.os.Build
import android.os.IBinder
import android.view.Display
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import android.app.AlertDialog
import android.widget.EditText
import android.os.Handler
import android.os.Looper

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private var bubble: TextView? = null
    private var panel: LinearLayout? = null
    private var seconds = 0
    private var running = false
    private val handler = Handler(Looper.getMainLooper())
    private var timerText: TextView? = null
    private var refreshText: TextView? = null
    private val tick = object : Runnable {
        override fun run() {
            if (running) {
                seconds++
                timerText?.text = "Stopwatch: ${seconds / 60}:${(seconds % 60).toString().padStart(2, '0')}"
                handler.postDelayed(this, 1000)
            }
        }
    }

    private fun params(width: Int, height: Int): WindowManager.LayoutParams {
        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                   else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
        return WindowManager.LayoutParams(width, height, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT)
            .apply { gravity = Gravity.TOP or Gravity.END; x = 12; y = 220 }
    }

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        showBubble()
    }

    private fun showBubble() {
        val b = TextView(this).apply {
            text = "G"; textSize = 20f; gravity = Gravity.CENTER
            setTextColor(Color.WHITE); setBackgroundColor(Color.rgb(190, 25, 35))
            setPadding(18, 14, 18, 14)
            setOnClickListener { if (panel == null) showPanel() else hidePanel() }
        }
        bubble = b
        val p = params(-2, -2)
        b.setOnTouchListener(object : android.view.View.OnTouchListener {
            var sx = 0f; var sy = 0f; var moved = false
            override fun onTouch(v: android.view.View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { sx=e.rawX; sy=e.rawY; moved=false; return true }
                    MotionEvent.ACTION_MOVE -> {
                        val dx=(sx-e.rawX).toInt(); val dy=(e.rawY-sy).toInt()
                        if (kotlin.math.abs(dx)>5 || kotlin.math.abs(dy)>5) moved=true
                        p.x=(p.x+dx).coerceAtLeast(0); p.y=(p.y+dy).coerceAtLeast(0)
                        wm.updateViewLayout(v,p); sx=e.rawX; sy=e.rawY; return true
                    }
                    MotionEvent.ACTION_UP -> { if (!moved) v.performClick(); return true }
                }
                return false
            }
        })
        wm.addView(b,p)
    }

    private fun showPanel() {
        val box = LinearLayout(this).apply {
            orientation=LinearLayout.VERTICAL; setPadding(18,16,18,16)
            setBackgroundColor(Color.rgb(24,24,24))
        }
        box.addView(TextView(this).apply {
            text="GAMING PANEL"; textSize=18f; setTextColor(Color.rgb(255,70,70))
            setPadding(0,0,0,10)
        })
        val fpsTitle = TextView(this).apply {
            text="FPS MONITOR"; textSize=15f; setTextColor(Color.WHITE)
        }
        box.addView(fpsTitle)
        refreshText = TextView(this).apply {
            text="Display refresh: ${getRefreshRate()} Hz"
            textSize=14f; setTextColor(Color.rgb(255,190,90)); setPadding(0,4,0,2)
        }
        box.addView(refreshText)
        box.addView(TextView(this).apply {
            text="Game FPS: unavailable to this app"
            textSize=12f; setTextColor(Color.LTGRAY); setPadding(0,0,0,10)
        })
        timerText=TextView(this).apply {
            text="Stopwatch: 0:00"; textSize=14f; setTextColor(Color.WHITE)
        }
        box.addView(timerText)
        fun button(label:String, action:()->Unit) {
            box.addView(Button(this).apply { text=label; setOnClickListener { action() } })
        }
        button("Start / pause stopwatch") {
            running=!running
            if(running) handler.post(tick) else handler.removeCallbacks(tick)
        }
        button("Reset stopwatch") {
            running=false; handler.removeCallbacks(tick); seconds=0
            timerText?.text="Stopwatch: 0:00"
        }
        button("Volume +") { adjustVolume(AudioManager.ADJUST_RAISE) }
        button("Volume -") { adjustVolume(AudioManager.ADJUST_LOWER) }
        button("Quick note") { showNoteDialog() }
        button("Refresh display reading") {
            refreshText?.text="Display refresh: ${getRefreshRate()} Hz"
        }
        button("Hide panel") { hidePanel() }
        panel=box
        wm.addView(box,params(270,-2).apply { flags=0 })
    }

    private fun getRefreshRate(): Int {
        return try {
            val display: Display? = if (Build.VERSION.SDK_INT >= 30) display
                else @Suppress("DEPRECATION") (wm.defaultDisplay)
            (display?.refreshRate ?: 0f).toInt()
        } catch (_: Exception) { 0 }
    }

    private fun adjustVolume(direction:Int) {
        val audio=getSystemService(Context.AUDIO_SERVICE) as AudioManager
        audio.adjustStreamVolume(AudioManager.STREAM_MUSIC,direction,AudioManager.FLAG_SHOW_UI)
    }

    private fun showNoteDialog() {
        val edit=EditText(this).apply { hint="Type a quick note" }
        val dialog=AlertDialog.Builder(this).setTitle("Gaming note").setView(edit)
            .setPositiveButton("Close") { _,_ ->
                Toast.makeText(this,edit.text.toString().ifBlank { "No note entered" },Toast.LENGTH_SHORT).show()
            }.setNegativeButton("Cancel",null).create()
        if (Build.VERSION.SDK_INT >= 26) dialog.window?.setType(WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY)
        dialog.show()
        if (Build.VERSION.SDK_INT >= 26) dialog.window?.setType(WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY)
    }

    private fun hidePanel() {
        panel?.let { try { wm.removeView(it) } catch (_:Exception) {} }; panel=null
    }

    override fun onDestroy() {
        running=false; handler.removeCallbacks(tick); hidePanel()
        bubble?.let { try { wm.removeView(it) } catch (_:Exception) {} }; bubble=null
        super.onDestroy()
    }
    override fun onBind(intent:Intent?):IBinder?=null
}
