REALME C53 GAMING SIDEBAR - ANDROID STUDIO SOURCE

Features:
- Movable red floating G button
- Show/hide black-and-red gaming panel
- Stopwatch with start/pause and reset
- Volume up/down controls
- Quick note dialog

Build:
1. Extract this ZIP.
2. Open the extracted folder in Android Studio.
3. Allow Gradle sync to finish.
4. Build > Build APK(s).
5. Install the APK on your Realme C53.
6. Open Gaming Sidebar and grant "Display over other apps".
7. Tap Start gaming sidebar, then open CODM.

Notes:
- This is source code, not a prebuilt APK.
- It does not display real FPS or change CODM graphics.
- Android may restrict overlays in some games or security modes.
- The overlay permission is sensitive. Grant it only to this app if you trust the source.
- Use Stop sidebar in the app to remove the floating button.
