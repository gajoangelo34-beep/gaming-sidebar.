REALME C53 GAMING SIDEBAR + FPS PANEL - SOURCE PROJECT v1.1

Included:
- Movable floating red G button
- Black/red gaming panel
- Stopwatch start/pause/reset
- Volume up/down
- Quick note dialog
- Display refresh-rate reading (Hz)
- Explicit message that actual CODM FPS is unavailable to this ordinary app

IMPORTANT FPS LIMITATION:
The panel reads the display's refresh rate, not the game's rendered FPS. Android generally does not let a normal third-party app inspect another app's live frame rate. Do not treat 90Hz as 90 FPS.

Build:
1. Extract this ZIP on a computer with Android Studio and Android SDK.
2. Open the extracted project folder.
3. Sync Gradle.
4. Build > Build APK(s).
5. Install the generated APK.
6. Grant Display over other apps permission.
7. Start the sidebar before opening CODM.

This ZIP is source code, not an installable APK. It has not been built or tested on a Realme C53. Overlay support may vary by firmware and game.

CLOUD BUILD WITHOUT A PC (GitHub Actions):
1. Create/sign in to a GitHub account in your phone browser.
2. Create a new repository.
3. Upload the contents of this project ZIP into the repository (extract ZIP first).
4. Open the Actions tab. If prompted, enable Actions.
5. Select "Build Gaming Sidebar APK" and tap "Run workflow".
6. Wait for the workflow to finish successfully.
7. Open the completed workflow run, find Artifacts, and download "Gaming-Sidebar-debug-apk".
8. Extract the downloaded artifact ZIP and install app-debug.apk on your phone.
9. If Android blocks installation, allow your browser/files app to install unknown apps only for this APK.

This workflow builds an unsigned debug APK suitable for personal testing. It is not a Play Store release.
